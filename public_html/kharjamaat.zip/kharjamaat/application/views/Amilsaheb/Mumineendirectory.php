<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        form {
            margin-bottom: 20px;
        }

        .card {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .sector-card {
            background-color: #e2e6ea;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block; 
            margin-right: 10px; 
        }

        @media only screen and (max-width: 600px) {
            .sector-card {
                display: block;
                margin-right: 0;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <div style="margin-top: 7rem;">
        

        <!-- Add Elastic Search form here -->
        <form>
            <input type="text" id="searchInput" placeholder="Search..." oninput="performSearch()">
        </form>

        <!-- Display total count of each sector and overall count -->
        <div class="card">
            <div class="sector-card" id="totalSectorCard">
                <!-- Total count will be displayed here -->
            </div>

            <div id="sectorCardsContainer">
                <!-- Each sector card will be added dynamically -->
            </div>
        </div>

        <!-- Display user data in a table -->
        <div style="overflow-x: scroll; ">
        <table id="userData">
            <thead>
                <tr>
                    <th>S.no.</th>
                    <th>ITS_ID</th>
                    <th>Full_Name</th>
                    <th>Age</th>
                    <th>Mobile</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Sector</th>
                    <th>HOF_ID</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $key => $user): ?>
                    <tr>
                        <td><?= $key + 1 ?></td>
                        <td><?= $user->ITS_ID ?></td>
                        <td><?= $user->Full_Name ?></td>
                        <td><?= $user->Age ?></td>
                        <td><?= $user->Mobile ?></td>
                        <td><?= $user->Email ?></td>
                        <td><?= $user->Address ?></td>
                        <td><?= $user->Sector ?></td>
                        <td><?= $user->HOF_ID ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    </div>

    <script>
        const originalData = <?= json_encode($users) ?>;

        // Display sector cards by default
        updateSectorCount(originalData);

        function performSearch() {
            var keyword = document.getElementById('searchInput').value.toLowerCase();
            var filteredData = originalData.filter(function(user) {
                return (
                    user.Full_Name.toLowerCase().includes(keyword) ||
                    user.ITS_ID.toLowerCase().includes(keyword) ||
                    user.HOF_ID.toLowerCase().includes(keyword) ||
                    user.Mobile.toLowerCase().includes(keyword) ||
                    user.Email.toLowerCase().includes(keyword) ||
                    user.Address.toLowerCase().includes(keyword) ||
                    user.Sector.toLowerCase().includes(keyword)
                    // Add more fields as needed
                );
            });

            // Update sector count
            updateSectorCount(filteredData);

            // Update user data table
            updateUserTable(filteredData);
        }

        function updateSectorCount(users) {
            var sectors = {};
            users.forEach(function(user) {
                sectors[user.Sector] = (sectors[user.Sector] || 0) + 1;
            });

            // Update total count
            var totalSectorCard = document.getElementById('totalSectorCard');
            totalSectorCard.textContent = 'Total Count: ' + users.length;

            var sectorCardsContainer = document.getElementById('sectorCardsContainer');
            sectorCardsContainer.innerHTML = '';

            for (var sector in sectors) {
                var count = sectors[sector];

                // Create a separate card for each sector
                var sectorCard = document.createElement('div');
                sectorCard.className = 'sector-card';
                sectorCard.textContent = 'Sector: ' + sector + ', Count: ' + count;

                sectorCardsContainer.appendChild(sectorCard);
            }
        }

        function updateUserTable(users) {
            var userTableBody = document.querySelector('#userData tbody');
            userTableBody.innerHTML = '';

            users.forEach(function(user, key) {
                var row = userTableBody.insertRow();
                var cell = row.insertCell(0);
                cell.textContent = key + 1;

                cell = row.insertCell(1);
                cell.textContent = user.ITS_ID;

                cell = row.insertCell(2);
                cell.textContent = user.Full_Name;

                cell = row.insertCell(3);
                cell.textContent = user.Age;

                cell = row.insertCell(4);
                cell.textContent = user.Mobile;

                cell = row.insertCell(5);
                cell.textContent = user.Email;

                cell = row.insertCell(6);
                cell.textContent = user.Address;

                cell = row.insertCell(7);
                cell.textContent = user.Sector;

                cell = row.insertCell(8);
                cell.textContent = user.HOF_ID;
            });
        }
    </script>
</body>
</html>
