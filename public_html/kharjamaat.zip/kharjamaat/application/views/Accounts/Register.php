<style>
    .center {
        display: flex;
        height: 100vh;
        width: 100vw;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        text-align: center;
    }
</style>
<div class="center">
    <h4>Contact Jamaat office</h4>
    <p>or</p>
    <h4>E-mail at <a href="mailto:anjuman@kharjamaat.in">anjuman@kharjamaat.in</a></h4>
</div>