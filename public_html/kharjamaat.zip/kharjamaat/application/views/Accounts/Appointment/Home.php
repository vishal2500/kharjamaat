<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Calendar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        /* .calendar-container {
            max-width: 800px;
            margin: auto;
            background-size: cover;
            background-position: center;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        } */

        .calendar-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .calendar-table {
            width: 100%;
            border-collapse: collapse;
            background-color: rgba(255, 255, 255, 0.8);
            /* Add a semi-transparent white background for better readability */
            border-radius: 8px;
            overflow: hidden;
            /* Ensure rounded corners are applied to the background */
        }

        .calendar-table th,
        .calendar-table td {
            text-align: center;
            border: 1px solid #ddd;

        }

        @media screen and (min-width:540px) {

            .calendar-table th,
            .calendar-table td {
                padding: 1rem;
            }
        }

        .date-link {
            display: block;
            color: #007bff;
            text-decoration: none;
            transition: background-color 0.3s ease;
            padding: 8px;
            border-radius: 4px;
            font-weight: bold;
        }

        .date-link:hover {
            background-color: #007bff;
            color: #fff;
        }

        /* Colorful styles for different date ranges */
        .date-past {
            background-color: #f8f9fa;
            color: #6c757d;
        }

        .date-current {
            background-color: #007bff;
            color: #fff;
        }

        .date-link {
            display: block;
            color: #007bff;
        }

        /* Responsive styles for smaller screens */
        @media (max-width: 300px) {

            .calendar-table th,
            .calendar-table td {
                font-size: 12px;
                /* Adjust font size for better visibility on smaller screens */
                padding: 0px;

            }

            .date-link {
                font-size: 12px;
                /* Adjust font size for better visibility on smaller screens */
                padding: 2px;
            }
        }



        /* Styles for buttons */
        .btn {
            display: inline-block;
            padding: 6px 12px;
            margin-bottom: 0;
            font-size: 14px;
            font-weight: 400;
            line-height: 1.42857143;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            cursor: pointer;
            background-image: none;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        /* Styles for delete button */
        .btn-danger {
            color: #fff;
            background-color: #d9534f;
            border-color: #d43f3a;
        }

        /* Styles for success button */
        .btn-success {
            color: #fff;
            background-color: #5cb85c;
            border-color: #4cae4c;
        }

        /* Styles for 'Not Attended' status */
        .status-not-attended {
            color: #d9534f;
            font-weight: bold;
        }

        /* Styles for 'Attended' status */
        .status-attended {
            color: #5cb85c;
            font-weight: bold;
        }

        .heading {
            color: #ad7e05;
            font-family: 'Amita', cursive;
        }

        .td {
            min-width: 100px;
        }
    </style>

</head>

<body>
    <div class="container margintopcontainer">
        <h1 class="text-center heading pt-4 mb-4">Welcome to Anjuman-e-Saifee Khar Jamaat</h1>
        <hr>

    </div>
    <div class="container calendar-container mt-4">
        <h4 class="text-center mb-4">Wajebaat Appointment Calendar</h4>


        <table class="calendar-table">
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $currentDate = new DateTime('2024-03-10');
                $endDate = new DateTime('2024-04-08');
                $numeric = [
                    "٠",
                    "١",
                    "٢",
                    "٣",
                    "٤",
                    "٥",
                    "٦",
                    "٧",
                    "٨",
                    "٩",
                    "١٠",
                    "١١",
                    "١٢",
                    "١٣",
                    "١٤",
                    "١٥",
                    "١٦",
                    "١٧",
                    "١٨",
                    "١٩",
                    "٢٠",
                    "٢١",
                    "٢٢",
                    "٢٣",
                    "٢٤",
                    "٢٥",
                    "٢٦",
                    "٢٧",
                    "٢٨",
                    "٢٩",
                    "٣٠",
                    "٣١"
                ];


                $ramazan = 1;
                while ($currentDate <= $endDate) {
                    echo '<tr>';
                    for ($i = 0; $i < 7; $i++) {
                        echo '<td>';
                        if ($currentDate >= new DateTime('2024-03-10') && $currentDate <= new DateTime('2024-04-08')) {
                            $formattedDate = $currentDate->format('Y-m-d');
                            echo '<a href="' . site_url('accounts/time_slots?date=' . $formattedDate) . '" onclick="return navigateToTimeslot();" class="date-link">' . $numeric[$ramazan++] . '</a>';
                        }
                        echo '</td>';
                        $currentDate->modify('+1 day');
                    }
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <script>
        function navigateToTimeslot() {
            let appointment = '<?php echo !empty($user_appointments) ? "yes" : "no"; ?>';
            if (appointment == 'yes') {
                alert('You have already selected your time slot');
                return false;
            } else {
                return true;
            }
        }
    </script>
    <?php

    usort($user_appointments, function ($a, $b) {
        return strtotime($a->date) - strtotime($b->date);
    });
    ?>

    <div class="container" style="margin-top:50px;">
        <h4 class="text-center mb-4">Your Appointments</h4>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($user_appointments as $appointment): ?>
                        <tr>
                            <td class="td">
                                <?php echo date('D, d M', strtotime($appointment->date)) ?>
                            </td>
                            <td class="td">
                                <?= $appointment->time ?>
                            </td class="td">
                            <td class="<?= ($appointment->status == 0) ? 'status-not-attended' : 'status-attended'; ?>">
                                <?= ($appointment->status == 0) ? 'Not Attended' : 'Attended'; ?>
                            </td>
                            <td>
                                <a href="<?= site_url('accounts/delete_appointment/' . $appointment->id) ?>"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Are you sure you want to delete this appointment?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</html>